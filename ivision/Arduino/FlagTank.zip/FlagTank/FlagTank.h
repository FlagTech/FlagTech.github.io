/*
  FlagTank.h - Library for Flag iTank Advance
  Created by FlagTech, 2014.
*/
#ifndef FlagTank_h
#define FlagTank_h

#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include "Wire.h"

// 輸出控制位址
#define ITANK_I2C      0x2a
#define ITANK_REAR_LEFT_MOTOR  0x03
#define ITANK_REAR_RIGHT_MOTOR 0x04
#define ITANK_LED              0x05
#define ITANK_DIGITAL_SWITCH   0x07
#define ITANK_SPEAKER    0x09
#define ITANK_SERVO      0x0a
#define ITANK_SERVO_PAN  0x10
#define ITANK_SERVO_TILT 0x11
#define ITANK_LCD_INT    0x12
#define ITANK_LCD_STR    0x1E

// 產品名稱
#define ITANK_NAME 0x80

// 輸入控制位址
#define ITANK_DIP_SWITCH 0x8A
#define ITANK_TACT_SWITCH 0x8B
#define ITANK_SOUND_SWITCH 0x8C
#define ITANK_TOUCH_SENSOR 0x8D
#define ITANK_TEMP_SENSOR 0x8E
#define ITANK_HUMID_SENSOR 0x90
#define ITANK_LIGHT_SENSOR 0x91
#define ITANK_IR_FLOOR     0x93
#define ITANK_IR_DISTANCE  0x94
#define ITANK_IR_TRACKING  0x98
#define ITANK_GEAR_SPEED_FL 0x9A
#define ITANK_GEAR_SPEED_FR 0x9B
#define ITANK_GEAR_SPEED_RL 0x9C
#define ITANK_GEAR_SPEED_RR 0x9D
#define ITANK_MOTOR_CURRENT_FL 0x9E
#define ITANK_MOTOR_CURRENT_FR 0x9F
#define ITANK_MOTOR_CURRENT_RL 0xA0
#define ITANK_MOTOR_CURRENT_RR 0xA1
#define ITANK_ANALOG_IN_0 0xA2
#define ITANK_ANALOG_IN_1 0xA4
#define ITANK_ANALOG_IN_2 0xA6
#define ITANK_ANALOG_IN_3 0xA8

//三軸加速度計(ADXL345)位址
#define ITANK_G_SENSOR 0x53
#define ITANK_G_SENSOR_X 50
#define ITANK_G_SENSOR_Y 52
#define ITANK_G_SENSOR_Z 54

// 揚聲器輸出時的升降音控制常數
#define SHARP   2    //升半音  
#define FLAT    1    //降半音

//------------------------------------------------------------------------------
/**
 * 表示紅外線追蹤模組資料的結構體
 */
struct Chaser {
  boolean noObject;//  有無偵測到物體
  byte sect;       // 追物方位
  byte dist;       // 追物距離
  boolean inside;  // 物體在安全距離內
};


/**
 * 表示3軸加速度計偵測值的結構體
 */
struct GSensor {
  float X;  // X 軸 
  float Y;  // Y 軸
  float Z;  // Z 軸
};

// 類別定義
class FlagTank
{
  public:
    FlagTank(); // 建構函式
    
    // 起始函式
    void begin();
 
    // 後馬達輸出控制
    boolean writeMotor(char left,char right);
    
    void stop();       // 停車
        
    // 控制板 LED 
    boolean writeLED(byte ledValue);
    
    // 控制板數位開關腳位
    boolean writeDigitalSW(byte outValue);
    
    // 控制板Speaker輸出
    boolean writeSpeaker(byte note);    // 簡易版
    boolean writeSpeaker(byte tone,     // 完整版
                         byte semiTone, 
                         byte pitchClass);
    
    // Servo控制
    boolean writeServo(byte number, byte degree);
    boolean writeServoPan(byte degree);
    boolean writeServoTilt(byte degree);
    
    // LCD 輸出控制
    boolean writeLCD(byte row, char ch);
    boolean writeLCD(byte row, byte value);
    boolean writeLCD(byte row, int value);
    boolean writeLCD(byte row, float value);
    boolean writeLCD(byte row, float value, byte precision);
    boolean writeLCD(byte row, char*  str);
    boolean writeLCD(byte row, String str);
    boolean writeLCDInt(byte row, unsigned int value);
    boolean clearLCD();
    boolean clearLCD(byte row);
    boolean clearLCDInt(byte row);
    
    //-----------------------------------------------------  
   
    // 讀取產品名稱
    String readName();  
    
    // 讀取DIP開關狀態
    byte readDip();
    
    // 讀取按鈕狀態值
    byte readKey();
    
    // 讀取按鈕狀態值, 延遲版 (適用於建立使用者介面)
    //     函式讀取1次按鍵值後, 會延遲數毫秒再讀1次
    //     兩次讀值都相同, 才會傳回該按鍵值
    // 參數: ms, 兩次讀值間的延遲時間(毫秒)
    byte readKeyDelayed(byte ms=75);
    
    // 讀取聲控開關狀態值
    boolean readSound();
    
    // 讀取車體前端碰撞開關狀態值
    byte readTouch();
    
    // 讀取溫度感測器值
    float readTemperature(); 
    
    // 讀取溼度感測器值
    byte readHumidity();
    
    // 讀取光感測器值
    float readLight();
    
    // 車頭紅外線追蹤模組
    Chaser readChaserIR();
    Chaser chaser;
    
    // 車體紅外線測距
    byte* readDistanceIR(); // 讀取目前感測值
    byte irDistance[4];     // 紀錄讀取的測距值 (左前、右前、左後、右後)
    
    // 車底循軌紅外線
    byte readFloorIR();
    
    // 控制板類比輸入腳位
    unsigned int readADC(byte pin);
    
    // 車體3軸加速度感測器
    GSensor readAccel();
    GSensor gValue;    // 紀錄讀取的G值
    
  // ------------------- 內部使用成員  
  private:
    byte byteBuf[16];  // 用來暫存資料的緩衝區
      
    // 透過 I2C 從 iTank 讀取資料
    boolean readFromTank(
      byte subaddr, // I2C 子位址
      byte len,     // 讀取位元組數
      byte buf[]);  // 資料的暫存區
    
    // 透過 I2C 寫入資料到 iTank
    boolean writeToTank( 
      byte subaddr, // I2C 子位址
      byte len,     // 位元組數
      byte buf[]);  // 資料的暫存區
    
    // 計算加速度計 G 值
    float calcGValue(byte lowByte, byte highByte);
};

extern FlagTank iTank;

#endif
