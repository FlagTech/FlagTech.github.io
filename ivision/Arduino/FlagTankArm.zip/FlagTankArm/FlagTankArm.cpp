#include "FlagTankArm.h"

/**
* 旗標 iTank 機械手臂函式庫
* @author Ken.Flag
* @version 1.0
*/

/**
* 轉動舵機到指定的角度
* @param servo 哪顆舵機, 範圍 0~3 (手臂由下到上)
* @param degree 轉動到多少度, 但若指定角度超過允許範圍則不轉動
* @return true 表示成功, false 表示有錯誤發生：指定Servo錯誤, 或指定角度超過範圍(因此未轉動)
*/
boolean FlagTankArm::turnTo(byte servo, byte degree)
{
	if(servo < 4) {   // 如果 servo 編號正確
		if(degree >= aMin[servo] && degree <= aMax[servo]) {   // 如果角度在許可範圍
      		iTank.writeServo(aSrv[servo], degree);	// 轉馬轉到指定角度
			aDeg[servo] = degree;             		// 更新目前角度
			return true;//轉動成功
		}
	}
	return false;	// 轉動失敗
}

/**
* 同時轉動 4 個舵機到指定角度, 角度超過允許範圍的舵機會被略過(不轉動)
* @param deg0~deg3 分別指定舵機 0~3(手臂由下到上) 要轉到幾度 
* @return 無
*/
void FlagTankArm::turnTo(byte deg0, byte deg1, byte deg2, byte deg3) { 
  turnTo(0,deg0); turnTo(1,deg1); turnTo(2,deg2); turnTo(3,deg3); 
}
  
/**
* 同時轉動 4 個舵機到指定角度 (以 byte 陣列指定角度), 角度超過允許範圍的舵機會被略過(不轉動)
* @param deg[] 為 byte 陣列, 其內 4 bytes 分別指定舵機 0~3(手臂由下到上) 要轉到幾度 
* @return 無
*/
void FlagTankArm::turnTo(byte deg[]) {
  for(byte i=0; i<4; i++) turnTo(i, deg[i]);
}    

/**
* 慢動作轉動 4 個舵機到指定角度, 角度超過允許範圍的舵機會被略過 (不轉動)
* @param deg0~3   分別指定舵機 0~3(手臂由下到上) 要轉到幾度
* @param tick 要多久才轉到定位 (1tick = 100ms), 例如 10 則慢動作會持續 1 秒
* @return 無
*/
void FlagTankArm::show(byte deg0, byte deg1, byte deg2, byte deg3, byte tick) {  // 1 tick = 100ms
  byte deg[4] = { deg0, deg1, deg2, deg3 };
  show(deg, tick);
}

/**
* 慢動作轉動 4 個舵機到指定角度 (以byte陣列指定角度), 角度超過允許範圍的舵機會被略過 (不轉動)
* @param deg[] 為 byte 陣列, 其內 4 bytes 分別指定舵機 0~3(手臂由下到上) 要轉到幾度 
* @param tick 要多久才轉到定位 (1tick = 100ms), 例如 10 則慢動作會持續 1 秒
* @return 無
*/
void FlagTankArm::show(byte deg[], byte tick) { 
  int tn[4];  // 需可存正負值
  byte sv, i; 
  for(sv=0; sv<4; sv++) {
  	if(deg[sv] > 180) deg[sv] = aDeg[sv];       // 若角度>180則略過該舵機 (角度不變)
    tn[sv] = ((int)deg[sv] - aDeg[sv]) / tick;  // 計算每 tick 要轉幾度
  }
  for(i=1; i<tick; i++) {  // 每 tick 轉動一次
    for(sv=0; sv<4; sv++) {
      turn(sv, tn[sv]);
    }
    delay(100);
  }
  turnTo(deg);  // 最後轉到目的角度
}

/**
* 正轉或反轉指定舵機幾度, 轉到允許角度範圍的邊界 (最大/最小角度) 時即停止
* @param servo 哪顆舵機
* @param degree 轉多少度, 可為正/負數值代表正/反轉
* @return true 表示有轉動 (只轉到允許的最大/最小角度也算), false 表示沒有轉動
*/
boolean FlagTankArm::turn(byte servo, int degree)
{
	if(servo < 4) {   // 如果 servo 編號正確
		int deg = aDeg[servo];
		deg += degree;
	    if(deg < aMin[servo]) deg = aMin[servo];   // 如果角度超過範圍, 只轉到允許的角度
          else if(deg > aMax[servo]) deg = aMax[servo];
  		if(deg != aDeg[servo]) {    // 如果有需要轉動 
  		  iTank.writeServo(aSrv[servo], deg);	// 轉到指定角度
  		  aDeg[servo] = deg;              		// 更新目前角度
		  return true; 							// 轉動成功(有轉動)
		}
	}
	return false;		// 轉動失敗(無轉動)
}

/**
* 讀取目前角度
* @param servo 哪顆舵機
* @return true 目前角度 (剛啟動時會傳回 90 度, 但不一定正確)
*/
byte FlagTankArm::read(byte servo) {
	return aDeg[servo];
}

/**
* 設定舵機預設角度
* @param deg0~deg3 分別指定舵機 0~3(手臂由下到上) 的預設角度
* @return 無
*/
void FlagTankArm::setDefault(byte deg0, byte deg1, byte deg2, byte deg3) {
	aDef[0] = deg0; aDef[1] = deg1; aDef[2] = deg2; aDef[3] = deg3; 
}

/**
* 設定舵機預設角度 (以byte陣列指定角度)
* @param deg[] 為 byte 陣列, 其內 4 bytes 分別指定舵機 0~3(手臂由下到上) 的預設角度
* @return 無
*/
void FlagTankArm::setDefault(byte deg[]) {
	for(byte i=0; i<4; i++)  aDef[i] = deg[i];
}

/**
* 設定目前角度為舵機預設角度
* @return 無
*/
void FlagTankArm::setDefault() {
	for(byte i=0; i<4; i++) aDef[i] = aDeg[i];
}

/**
* 將各舵機轉到預設角度 (剛啟動時預設均為 90 度)
* @return 無
*/
void FlagTankArm::turnToDefault() {
	turnTo(aDef[0], aDef[1], aDef[2], aDef[3]); 
}

/**
* 慢動作將各舵機轉到預設角度 (剛啟動時預設均為 90 度)
* @param tick 要多久才轉到定位 (1tick = 100ms), 例如 10 則慢動作會持續 1 秒
* @return 無
*/
void FlagTankArm::showDefault(byte tick) {
	show(aDef[0], aDef[1], aDef[2], aDef[3], tick); // 慢動作轉 (tick*100 ms)
}

/**
* 設定舵機允許的角度範圍, 超過即忽略操作
* @param servo 哪顆舵機
* @param degMin 最小允許角度
* @param degMax 最大允許角度, 必須 > degMin, 且 <= 180
* @return 無
*/
void FlagTankArm::setRange(byte servo, byte degMin, byte degMax){
	if(degMin < degMax && degMax <= 180) {
		aMin[servo] = degMin; 
		aMax[servo] = degMax;
	}
}

//設定 4 顆 Servo 的連接腳位, 需配合實際接線 (預設 6,7,4,5 = Sv6,Sv7,Sv4,Sv5)
/**
* 設定舵機允許的角度範圍, 超過即忽略操作
* @param servo 哪顆舵機
* @param degMin 最小允許角度
* @param degMax 最大允許角度, 必須 > degMin, 且 <= 180
* @return 無
*/
void FlagTankArm::setServoPin(byte pinPan, byte pinTilt, byte pinArm, byte pinHand) {
	aSrv[0] = pinPan; aSrv[1] = pinTilt; aSrv[2] = pinArm; aSrv[3] = pinHand;   
}


FlagTankArm iArm = FlagTankArm(); 	// 預先建構 iTank Arm 物件, 以便直接使用
