/**
* @file FlagTankArm.h - Library for Flag iTank's iArm
* Created by Ken@FlagTech, 2017.6
*/

#ifndef FlagTankArm_h
#define FlagTankArm_h

#include <FlagTank.h>   // 引用 FlagTank 函式庫

/**
* 旗標 iTank 機械手臂類別
* @author Ken.Flag
* @version 1.0
*/
class FlagTankArm
{
  // ------------------- 私用成員 ----------------------- 
  private:
    byte aSrv[4] = {   0,   1,   2,   3 };  // 各伺服馬達編號
	byte aDeg[4] = {  90,  90,  90,  90 };  // 各伺服馬達目前的角度
	byte aDef[4] = {  30,  20,  90,  90 };  // 各伺服馬達預設角度
	byte aMin[4] = {   0,   0,   0,   0 };  // 各伺服馬達角度最小值
	byte aMax[4] = { 180, 180, 180, 180 };  // 各伺服馬達角度最大值
	
  // ------------------- 公用成員 ----------------------- 
  public:
	
    //指定舵機編號來操作, 參數 servo=0~3(舵機由下到上), 所有舵機在啟動時均會先轉到 90 度
	boolean turnTo(byte servo, byte degree);  // 轉動舵機-到幾度, 會傳回成敗(舵機編號或角度超出範圍時傳回False)
	boolean turn(byte servo, int degree);     // 轉動舵機-轉幾度(正負數表正反轉), 會傳回成敗(舵機編號或角度超出範圍時傳回False)
	byte read(byte Servo);					  // 讀取舵機目前的角度 (需先用 turnTo() 設定過才行, 否則為預設的90度)
	
	//一次轉動 4 個舵機到指定角度
	void turnTo(byte deg0, byte deg1, byte deg2, byte deg3);  	// 轉動 4 個舵機到指定角度
	void turnTo(byte deg[]);  			                        // 轉動 4 個舵機到指定角度 (以陣列指定角度)
	void show(byte deg0, byte deg1, byte deg2, byte deg3, byte tick); // 慢動作轉到指定角度 (1tick = 100ms)
	void show(byte deg[], byte tick);           // 慢動作轉到指定角度 (1tick = 100ms) (以陣列指定角度)
	
	// ********************************************
	// ***************** 進階函式 *****************
	// ********************************************
		
	// 設定/展示預設姿勢 (每次啟動時舵機預設角度均為 90 度)
    void setDefault(byte deg0, byte deg1, byte deg2, byte deg3); // 設定舵機預設姿勢的角度
    void setDefault(byte deg[]);    // 設定舵機預設姿勢的角度 (以陣列指定)
    void setDefault();              // 將目前角度設定為舵機預設角度
    void turnToDefault();  	 		// 快速轉到舵機預設姿勢
    void showDefault(byte tick);    // 慢速轉到舵機預設姿勢 (1tick = 100ms)

	//設定馬達允許的角度範圍, 超過即忽略操作 (每次啟動時舵機預設角度範圍均為 0~180 度)
	void setRange(byte Servo, byte degMin, byte degMax); // 必須 degMin < degMax 且 degMax<= 180
	
	//設定 4 顆 Servo 的連接腳位, 需配合實際接線 (每次啟動時舵機0~3預設連接到 Sv0~3)
	void setServoPin(byte pin0, byte pin1, byte pin2, byte pin3);  
};

extern FlagTankArm iArm;

#endif
