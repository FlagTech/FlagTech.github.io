#include "FlagTankVision.h"

/**
* 旗標 iTank iVision 類別
* @author Ken.Flag
* @version 1.0
*/

/**
* 初始化Serial 
* @param baud baudrate, 若省略預設為 19200 (iVision的預設值)
*/
void FlagTankVision::initSerial() {
  initSerial(19200);      // iVision 預設為 19200 baudrate
}
void FlagTankVision::initSerial(long baud) {
  Serial.begin(baud);       
  Serial.setTimeout(100);   // 讀取逾時設為 0.1 秒  
}


/**
* 檢查是否有資料可讀取 
* @return True表示有資料可讀取, false則反之
*/
boolean FlagTankVision::checkRead() {
  return Serial.available()>0;
}

/**
* 讀取資料 
* @return 讀取訊息, 傳回讀到訊息的種類, 若傳回0表示沒讀到資料(還會將type設為0,其他資料則不變)
*/
char FlagTankVision::read() {
  byte b, bxor; 
  while(Serial.available()) {
    b = Serial.read();
    if(b==0xAA) {  // iVision data pack 
      if(Serial.readBytes(buf, 3)!=3) continue;   // 應是 0xBB+Len+Cmd
      if(buf[0]!=0xBB || buf[1]>READBUFSIZE) continue;    // 表頭錯誤or長度太長
      type = buf[2];
      len = buf[1]-1;     // parm 的長度 (扣掉cmd[1])
      bxor = buf[1] ^ buf[2];
      if(Serial.readBytes(buf, len)!=len) continue; // 讀取 parm
      if(type=='r' || type =='s') {
        x = ((int)buf[0]<<8) + buf[1];
        y = ((int)buf[2]<<8) + buf[3];
        area = ((long)buf[4]<<24) + ((long)buf[5]<<16) + ((long)buf[6]<<8) + buf[7];
        r = buf[8];
        if(type=='r') r = (r<<8) + buf[9];  // 若為圓形的半徑為2bytes, 否則為端點數[1]
      }
      if(type=='i') {
        memset(conninfo_buf, 0, CONNINFOBUFSIZE);
        memcpy(conninfo_buf, buf, CONNINFOBUFSIZE<=len?CONNINFOBUFSIZE:len);
      }
      for(byte i=0; i<len; i++) bxor ^= buf[i];
      if(Serial.readBytes(&b, 1)!=1) continue;      // 讀取 xor
      if(bxor != b) { 
        continue; 
      }
      return type;
    }
    else if(b==0xFF) {
      //iTank pack: 0xFF+{0xFF|0xFE}+指令[1]+參數[0~2]+0xFF+{0xFF|0xFE}+0x00(0xFE為需要傳回資料的指令格式)
      type = 't';
      buf[0] = 0xFF;
      if(Serial.readBytes(buf+1, 4)!=4) continue;   // 讀取 4 bytes: {0xFF|0xFE}+指令[1]+參數[0~2]+0xFF+{0xFF|0xFE}
      if(buf[1]!=0xFF && buf[1]!=0xFE) continue;    // 表頭錯誤
      for(byte i=0; i<3; i++) {                     // 讀取表尾的0x00 (因參數長度可能為0~2, 要讀3次)
        if(Serial.readBytes(&b, 1)!=1) continue; 
        buf[5+i] = b;
        if(b==0x00) return type;                    // 已讀到表尾的 0
      }
      continue;  // 錯誤:沒有表尾 0
    }
  }
  type = 0;
  return 0; // 沒讀到資料
}


// private method
void FlagTankVision::sendPack(byte cmd, byte parmlen, byte parm[]) {
//  Serial.println(String("send:")+(char)cmd+" parmlen="+parmlen+" parm="+parm[0]+","+parm[1]+","+parm[2]+","+parm[3]+","+parm[4]+","+parm[5]);
  Serial.write(0xAA); Serial.write(0xBB);   // write Header
  parmlen++;                                // dataLen = Cmd(1)+parmLen
  Serial.write(parmlen);Serial.write(cmd);  // write Len+cmd
  byte bxor = parmlen ^ cmd;                // checksum(xor)
  if(parmlen > 1) {
    parmlen--;
    Serial.write(parm, parmlen);            // send all parm array
    for(byte i=0; i<parmlen; i++) {
      bxor ^= parm[i];                      // checksum(xor)
    }
  }
  Serial.write(bxor);                         // write checkSum
}
void FlagTankVision::sendPack(byte cmd) {   // no parm version
  sendPack(cmd, 0, 0);
}

/**
* 設定辨識顏色範圍
* @param rgbh  byte陣列, 內含至少3bytes (R紅/G綠/B藍的顏色值), 也可以有4~6個bytes (H色彩(或稱色相)、S飽和度%、V明亮度%的範圍)
* @param len   指定陣列的長度, 省略時預設為 3, 只允許 3~6 (依序為 RGB,HSV)
* [註1] RGB範圍:0~255, H範圍:0~359度, SV範圍:0~100%。
* [註2] RGB是指定顏色的值, HSV是指定顏色的範圍, 例如H設為2, 則指定顏色的色彩值『由減2到加2』之間的顏色都符合
* [註3] HSV若未指定, 則均會自動設定為其預設值: 4、40、100。
* [註4] 在計算S或V的誤差容許範圍時, 上限值若大於100會改為100, 下限值若小於20會改為20。設為100時, 會自動變成 20%~100% 範圍
*/
void FlagTankVision::findColor(byte rgb_hsv[], byte len) { 
byte ca[] = { 0, 0, 0, 4, 40, 100 };
  if(len >=3 && len <= 6) {
  	for(byte i=0; i<len; i++) ca[i] = rgb_hsv[i];
  	sendPack('c', 6, ca);
  }
}

/**
* 設定辨識圓形
*/
void FlagTankVision::findCircle() { 
  sendPack('r');
}

/**
* 設定辨識方形 (4~6邊形)
*/
void FlagTankVision::findSquare() { 
  sendPack('s');
}

/**
 * 暫不實作！因為目前用不到, 且需增加 24bytes 空間來儲存座標值
 * 設定辨識方形(4~6邊形), 並且要多傳回所有端點的座標
void FlagTankVision::findSquareEp() { 
  sendPack(1, 's', 0);
}
*/

/**
* 停止辨識
*/
void FlagTankVision::findStop() { 
  sendPack('x');
}

/**
* 查詢 iVision 版本
*/
void FlagTankVision::getVersion() { 
  sendPack('v');
}

/**
* 查詢 iVision 的連線資訊
*/
void FlagTankVision::getConnInfo() { 
  sendPack('i');
}

/**
* 顯示偵錯訊息
* @param msg 要顯示的字串
*/
void FlagTankVision::showMsg(char *msg) { 
  sendPack('d', strlen(msg), (byte*)msg);
}

/**
* 顯示偵錯訊息
* @param str 要顯示的 String 物件
*/
void FlagTankVision::showMsg(String str) { 
  sendPack('d', str.length(), (byte*)(str.c_str()));
}

// 預先建構 iVision 物件, 以便直接使用
FlagTankVision iVision = FlagTankVision();	
