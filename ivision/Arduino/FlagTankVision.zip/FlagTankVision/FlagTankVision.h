/**
* @file FlagTankVision.h - 旗標 iTank's iVision 函式庫
* Created by Ken@FlagTech, 2018.2
*/

#ifndef FlagTankVision_h
#define FlagTankVision_h

#include <FlagTank.h>   // 引用 FlagTank 函式庫

#define READBUFSIZE 50
#define CONNINFOBUFSIZE 28 // 連線資訊, CONNINFOBUFSIZE 必須 <= READBUFSIZE

/**
* 旗標 iTank iVision 類別
* @author Ken.Flag
* @version 1.0
*/

class FlagTankVision
{
  // ------------------- 私用成員 ----------------------- 
  private:
    void sendPack(byte cmd, byte parmLen, byte parm[]);   // 打包並送出資料, 參數包含命令字元及附帶資料
    void sendPack(byte cmd);                              // 打包並送出資料, 參數只包含命令字元
    
  // ------------------- 公用成員 ----------------------- 
  public:
    char type = 0;      // 訊息種類
    byte len = 0;       // data長度
    int x, y, r;   		// 中心點座標(x,y), 半徑or端點數
    long area;     		// 面積
    char conninfo_buf[CONNINFOBUFSIZE];
    byte buf[READBUFSIZE];

    void initSerial();              // 初始化(將 Serial 設為 19200, Timeout 設為 0.2 秒)
    void initSerial(long baud);     // 初始化, 並指定 Baudrate
    void findColor(byte rgb_hsv[], byte len=3);    // 設定辨識RGB顏色, 可再加上HSV的容許範圍, len 為rgb_hsv陣列長度(3~6,若省略此參數則預設為 3)
    void findCircle();              // 設定辨識圓形
    void findSquare();              // 設定辨識方形 (4~6邊形)
    void findStop();                // 停止辨識
    void getVersion();              // 查詢版本
    void getConnInfo();             // 查詢連線資訊
    void showMsg(char *msg);        // 顯示偵錯訊息
    void showMsg(String str);       // 顯示偵錯訊息(參數為String物件)
    bool checkRead(); 				// 檢查是否有資料可讀取
    char read();                    // 讀取訊息, 傳回讀到訊息的種類, 若傳回0表示沒讀到資料(還會將type設為0,其他資料不變)
};

extern FlagTankVision iVision;

#endif
